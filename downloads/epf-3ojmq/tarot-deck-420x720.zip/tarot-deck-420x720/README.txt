ไพ่ทาโรต์ 78 ใบ + หลังไพ่ — ของเสริมสำหรับผู้อ่าน "เปิดไพ่ ฟังใจ" (Books by Dan)
Tarot deck, 78 cards + card back — a free extra for readers of "เปิดไพ่ ฟังใจ"

ภาพสร้างด้วย AI กำกับองค์ประกอบโดย Dan · © 2026 ArtproDucktion
Images generated with AI, art-directed by Dan · © 2026 ArtproDucktion

ขนาด: 420×720 px (7:12 เท่าไพ่จริง 70×120 มม.) เหมาะกับหน้าจอ/แอป
รูปแบบไฟล์: PNG มุมมนโปร่งใส

ชื่อไฟล์
- major-NN-ชื่อ.png  ไพ่ชุดใหญ่ 00 (fool) ถึง 21 (world)
- <ชุด>-NN-<ลำดับ>.png  ไพ่ชุดเล็ก: wands / cups / swords / pentacles · 01 ace, 02 two … 10 ten, 11 page, 12 knight, 13 queen, 14 king
- back.png  หลังไพ่

เงื่อนไขการใช้
- ใช้ส่วนตัวเท่านั้น (ดูประกอบการอ่านหนังสือ ใช้ในแอปเปิดไพ่ของตัวเอง พิมพ์ไว้ใช้เอง)
- ห้ามขายต่อ ห้ามแจกจ่ายต่อ ห้ามใช้เชิงพาณิชย์ ห้ามนำไปฝึก AI
- Personal use only. No resale, redistribution, commercial use, or AI training.

ไพ่ชุดเดียวกับโต๊ะเปิดไพ่ออนไลน์ของหนังสือ
